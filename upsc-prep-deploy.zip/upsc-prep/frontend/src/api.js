// Set this to your deployed backend URL after deploying to Railway/Render
// e.g. "https://upsc-prep-backend.railway.app"
// For local development, use "http://localhost:5000"
const BACKEND_URL = process.env.REACT_APP_BACKEND_URL || "http://localhost:5000";

export async function fetchNotes(subject, topic) {
  const res = await fetch(`${BACKEND_URL}/api/notes`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ subject, topic }),
  });
  const data = await res.json();
  if (data.error) throw new Error(data.error);
  return data.content;
}

export async function fetchChat(messages, system = "") {
  const res = await fetch(`${BACKEND_URL}/api/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ messages, system, max_tokens: 800 }),
  });
  const data = await res.json();
  if (data.error) throw new Error(data.error);
  return data.content;
}
