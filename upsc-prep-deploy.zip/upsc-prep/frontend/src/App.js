import { useState, useRef } from "react";
import { fetchNotes, fetchChat } from "./api";

const SUBJECTS = [
  { id: "gs1", name: "GS Paper I", icon: "🏛️", color: "#1a6b4a", bg: "#e1f5ee", topics: ["History", "Geography", "Society", "Art & Culture"] },
  { id: "gs2", name: "GS Paper II", icon: "⚖️", color: "#185fa5", bg: "#e6f1fb", topics: ["Polity", "Governance", "International Relations", "Social Justice"] },
  { id: "gs3", name: "GS Paper III", icon: "🌾", color: "#854f0b", bg: "#faeeda", topics: ["Economy", "Environment", "Science & Tech", "Security"] },
  { id: "gs4", name: "GS Paper IV", icon: "💡", color: "#533489", bg: "#eeedfe", topics: ["Ethics", "Integrity", "Aptitude", "Case Studies"] },
  { id: "csat", name: "CSAT", icon: "🧮", color: "#993c1d", bg: "#faece7", topics: ["Comprehension", "Reasoning", "Maths", "Decision Making"] },
  { id: "essay", name: "Essay", icon: "✍️", color: "#3b6d11", bg: "#eaf3de", topics: ["Essay Writing", "Language Skills", "Structure", "Previous Topics"] },
];

const SYLLABUS = {
  gs1: { "History": ["Indian Culture (Harappan to Mughal)", "Modern India (1857–1947)", "Post-Independence Consolidation", "World History (18th–20th Century)"], "Geography": ["Salient Features of World Physical Geography", "Distribution of Key Natural Resources", "Geophysical Phenomena", "Changes in Critical Geographical Features"], "Society": ["Salient Features of Indian Society", "Diversity of India", "Role of Women and Women's Organisation", "Population & Associated Issues"], "Art & Culture": ["Indian Art Forms", "Architecture", "Literature", "Performing Arts"] },
  gs2: { "Polity": ["Indian Constitution", "Functions of Parliament", "Judiciary", "Federalism & Centre-State Relations", "Constitutional Bodies"], "Governance": ["Government Policies & Schemes", "E-governance", "SHGs, NGOs", "Welfare Schemes"], "International Relations": ["India & Neighbourhood", "Bilateral/Global Groupings", "Effect of Foreign Policies on India"], "Social Justice": ["Mechanisms against Vulnerable Sections", "Issues relating to Health, Education, Poverty"] },
  gs3: { "Economy": ["Indian Economy", "Inclusive Growth", "Government Budgeting", "Agriculture & Food Security"], "Environment": ["Conservation", "Environmental Pollution", "Climate Change", "Disaster Management"], "Science & Technology": ["Developments in IT & Space", "Biotechnology", "IP Rights"], "Security": ["Internal Security Challenges", "Border Management", "Cyber Security"] },
  gs4: { "Ethics": ["Ethics & Human Interface", "Human Values", "Role of Family, Society, Educational Institutions"], "Integrity": ["Attitude", "Emotional Intelligence", "Contributions of Moral Thinkers"], "Aptitude": ["Probity in Governance", "Philosophical Basis of Governance & Probity"], "Case Studies": ["Case Studies on Above Issues"] },
  csat: { "Comprehension": ["Reading Comprehension", "Passage Analysis", "Inference Drawing"], "Reasoning": ["Logical Reasoning", "Analytical Ability"], "Maths": ["Basic Numeracy", "Data Interpretation"], "Decision Making": ["Problem Solving", "General Mental Ability"] },
  essay: { "Essay Writing": ["Introduction Techniques", "Body Structure", "Conclusion Methods"], "Language Skills": ["Vocabulary", "Grammar", "Sentence Construction"], "Structure": ["Topic Analysis", "Planning & Outlining"], "Previous Topics": ["Philosophy & Ethics", "Society", "Economy", "Governance"] },
};

const PYQ_BANK = [
  { year: 2023, paper: "GS1", q: "Assess the importance of the Pala Empire in the context of Indian cultural history.", subject: "gs1", topic: "History", type: "mains", marks: 15 },
  { year: 2023, paper: "GS2", q: "Discuss the role of the Finance Commission in maintaining fiscal federalism in India.", subject: "gs2", topic: "Polity", type: "mains", marks: 15 },
  { year: 2023, paper: "GS3", q: "How is the government of India working to reduce carbon intensity of the economy?", subject: "gs3", topic: "Environment", type: "mains", marks: 15 },
  { year: 2022, paper: "GS1", q: "Discuss the main features of Vedic society and religion. Do you think some of the features are still prevailing in Indian society today? Critically examine.", subject: "gs1", topic: "History", type: "mains", marks: 15 },
  { year: 2022, paper: "GS2", q: "Examine the legitimacy of judicial review in the context of separation of powers.", subject: "gs2", topic: "Polity", type: "mains", marks: 10 },
  { year: 2023, paper: "Prelims", q: "With reference to the Indian economy, 'Open Market Operations' refers to:", subject: "gs3", topic: "Economy", type: "prelims", options: ["Borrowing by scheduled banks from the RBI", "Lending by commercial banks to industry and trade", "Purchase and sale of government securities by the RBI", "None of the above"], answer: 2, explanation: "Open Market Operations (OMO) refers to the RBI buying or selling government securities in the open market to control liquidity." },
  { year: 2023, paper: "Prelims", q: "Consider the following statements about 'Pradhan Mantri Jan Dhan Yojana':\n1. It is a financial inclusion scheme.\n2. Zero-balance accounts are allowed.\n3. It provides accidental insurance cover.\nWhich of the above is/are correct?", subject: "gs2", topic: "Governance", type: "prelims", options: ["1 only", "1 and 2 only", "2 and 3 only", "1, 2 and 3"], answer: 3, explanation: "PMJDY allows zero-balance accounts and provides ₹1 lakh accidental insurance and ₹30,000 life insurance." },
  { year: 2022, paper: "Prelims", q: "Which one of the following statements best describes the 'Gram Nyayalayas Act'?", subject: "gs2", topic: "Polity", type: "prelims", options: ["It provides for fast-track courts for speedy trial", "It provides for village courts for trial of certain offences", "It establishes courts for civil disputes only", "It provides for Lok Adalat at village level"], answer: 1, explanation: "Gram Nyayalayas Act, 2008 provides for establishment of mobile courts at the grassroots level for speedy disposal of cases." },
  { year: 2021, paper: "Prelims", q: "'Agenda 21' sometimes seen in news is:", subject: "gs3", topic: "Environment", type: "prelims", options: ["UN framework on climate change", "Action plan for sustainable development from Rio Summit 1992", "Nuclear non-proliferation treaty", "Paris Agreement on emissions"], answer: 1, explanation: "Agenda 21 is a non-binding action plan related to sustainable development, produced at the 1992 Earth Summit in Rio." },
  { year: 2020, paper: "Prelims", q: "With reference to 'Ease of Doing Business Index', which of the following is correct?", subject: "gs2", topic: "Governance", type: "prelims", options: ["It is published by the World Economic Forum", "It is published by the World Bank", "It is published by UN Development Programme", "It is published by WTO"], answer: 1, explanation: "The Ease of Doing Business Index is published by the World Bank Group." },
];

const PROGRESS = { gs1: 45, gs2: 60, gs3: 30, gs4: 75, csat: 55, essay: 20 };

export default function App() {
  const [view, setView] = useState("dashboard");
  const [activeSub, setActiveSub] = useState(null);
  const [activeTopic, setActiveTopic] = useState(null);
  const [testMode, setTestMode] = useState(null);
  const [testQs, setTestQs] = useState([]);
  const [testIdx, setTestIdx] = useState(0);
  const [selected, setSelected] = useState(null);
  const [answered, setAnswered] = useState(false);
  const [score, setScore] = useState({ correct: 0, wrong: 0, total: 0 });
  const [testDone, setTestDone] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiContent, setAiContent] = useState("");
  const [filterYear, setFilterYear] = useState("All");
  const [filterType, setFilterType] = useState("All");
  const [syllEx, setSyllEx] = useState({});
  const [notes, setNotes] = useState({});
  const [noteInput, setNoteInput] = useState("");
  const [chatMsgs, setChatMsgs] = useState([{ role: "assistant", text: "Namaste! 🙏 I'm your UPSC AI Mentor. Ask me anything — concepts, current affairs, exam strategy, or answer writing tips." }]);
  const [chatInput, setChatInput] = useState("");
  const [chatLoading, setChatLoading] = useState(false);
  const chatEnd = useRef(null);

  const startTest = (type, subId) => {
    let pool = PYQ_BANK.filter(q => q.type === type && (!subId || q.subject === subId));
    if (filterYear !== "All") pool = pool.filter(q => q.year.toString() === filterYear);
    const shuffled = [...pool].sort(() => Math.random() - 0.5).slice(0, Math.min(5, pool.length));
    if (!shuffled.length) { alert("No questions found. Try a different filter."); return; }
    setTestQs(shuffled); setTestIdx(0); setSelected(null); setAnswered(false);
    setScore({ correct: 0, wrong: 0, total: 0 }); setTestDone(false); setTestMode(type); setView("test");
  };

  const handleAnswer = (i) => {
    if (answered) return;
    setSelected(i); setAnswered(true);
    const ok = i === testQs[testIdx].answer;
    setScore(s => ({ correct: s.correct + (ok ? 1 : 0), wrong: s.wrong + (ok ? 0 : 1), total: s.total + 1 }));
  };

  const nextQ = () => {
    if (testIdx + 1 >= testQs.length) { setTestDone(true); return; }
    setTestIdx(i => i + 1); setSelected(null); setAnswered(false);
  };

  const loadAI = async (sub, topic) => {
    setAiLoading(true); setAiContent("");
    try {
      const content = await fetchNotes(sub, topic);
      setAiContent(content);
    } catch (e) {
      setAiContent("Failed to load. Make sure the backend is running.");
    }
    setAiLoading(false);
  };

  const sendChat = async () => {
    if (!chatInput.trim() || chatLoading) return;
    const msg = chatInput.trim(); setChatInput("");
    setChatMsgs(m => [...m, { role: "user", text: msg }]); setChatLoading(true);
    try {
      const hist = chatMsgs.map(m => ({ role: m.role, content: m.text }));
      const reply = await fetchChat(
        [...hist, { role: "user", content: msg }],
        "You are an expert UPSC coach. Give concise, exam-focused answers. Use bullet points. Reference syllabus, PYQs, current affairs where relevant. Be encouraging."
      );
      setChatMsgs(m => [...m, { role: "assistant", text: reply }]);
    } catch {
      setChatMsgs(m => [...m, { role: "assistant", text: "Connection error. Is the backend running?" }]);
    }
    setChatLoading(false);
  };

  const C = {
    nav: { background: "#1a1a2e", color: "#fff", padding: "0 16px", display: "flex", alignItems: "center", justifyContent: "space-between", height: 54, position: "sticky", top: 0, zIndex: 100 },
    brand: { fontSize: 18, fontWeight: 800, color: "#ffd700", letterSpacing: 1 },
    nb: (a) => ({ background: a ? "#ffd700" : "transparent", color: a ? "#1a1a2e" : "#bbb", border: "none", padding: "5px 12px", borderRadius: 6, cursor: "pointer", fontWeight: a ? 700 : 400, fontSize: 12 }),
    main: { maxWidth: 1050, margin: "0 auto", padding: "20px 14px" },
    card: { background: "#fff", borderRadius: 12, border: "1px solid #e8eaf0", padding: "16px 18px", boxShadow: "0 1px 6px rgba(0,0,0,0.06)" },
    h1: { fontSize: 24, fontWeight: 800, color: "#1a1a2e", marginBottom: 4 },
    h2: { fontSize: 17, fontWeight: 700, color: "#1a1a2e", marginBottom: 10 },
    muted: { color: "#777", fontSize: 13 },
    btn: (p) => ({ background: p ? "#1a1a2e" : "#fff", color: p ? "#ffd700" : "#333", border: p ? "none" : "1.5px solid #ddd", padding: "7px 16px", borderRadius: 8, cursor: "pointer", fontWeight: 600, fontSize: 13 }),
    input: { width: "100%", padding: "9px 13px", borderRadius: 8, border: "1.5px solid #ddd", fontSize: 13, outline: "none", fontFamily: "inherit" },
    tag: (c, bg) => ({ background: bg || "#eeedfe", color: c || "#533489", fontSize: 11, padding: "2px 9px", borderRadius: 20, fontWeight: 600 }),
  };

  // ---- Sub-views ----

  const Dashboard = () => (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 10, marginBottom: 20 }}>
        <div>
          <h1 style={C.h1}>📚 UPSC Preparation Hub</h1>
          <p style={C.muted}>Your complete IAS preparation platform</p>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button style={C.btn(true)} onClick={() => startTest("prelims", null)}>🎯 Prelims Test</button>
          <button style={C.btn(false)} onClick={() => startTest("mains", null)}>📝 Mains Test</button>
        </div>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(130px,1fr))", gap: 10, marginBottom: 20 }}>
        {[{l:"PYQs in Bank",v:"10+",i:"❓"},{l:"Test Attempts",v:"18",i:"✅"},{l:"Topics",v:"47",i:"📖"},{l:"Day Streak",v:"12",i:"🔥"}].map(s=>(
          <div key={s.l} style={{...C.card,textAlign:"center",padding:"14px 10px"}}>
            <div style={{fontSize:26}}>{s.i}</div>
            <div style={{fontSize:22,fontWeight:800,color:"#1a1a2e"}}>{s.v}</div>
            <div style={{fontSize:11,color:"#888"}}>{s.l}</div>
          </div>
        ))}
      </div>
      <h2 style={{...C.h2,marginBottom:14}}>Subjects & Progress</h2>
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(270px,1fr))",gap:12,marginBottom:20}}>
        {SUBJECTS.map(s=>(
          <div key={s.id} style={{background:s.bg,border:`2px solid ${s.color}25`,borderRadius:12,padding:"14px 16px",cursor:"pointer"}}
            onClick={()=>{setActiveSub(s.id);setView("subject");}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:6}}>
              <span style={{fontSize:26}}>{s.icon}</span>
              <span style={C.tag(s.color,"#fff8")}>{PROGRESS[s.id]}%</span>
            </div>
            <div style={{fontWeight:700,fontSize:15,color:s.color,marginBottom:6}}>{s.name}</div>
            <div style={{height:6,borderRadius:3,background:"#ddd",overflow:"hidden",marginBottom:8}}>
              <div style={{height:"100%",width:`${PROGRESS[s.id]}%`,background:s.color,borderRadius:3}}/>
            </div>
            <div style={{display:"flex",flexWrap:"wrap",gap:4}}>
              {s.topics.slice(0,3).map(t=><span key={t} style={{fontSize:10,background:"#fff7",padding:"2px 7px",borderRadius:10,color:s.color,fontWeight:600}}>{t}</span>)}
            </div>
          </div>
        ))}
      </div>
      <div style={C.card}>
        <h2 style={{...C.h2,marginBottom:12}}>🗞️ Current Affairs Focus Areas</h2>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(180px,1fr))",gap:8}}>
          {[{t:"India-Maldives Relations",c:"Intl. Relations",imp:"High"},{t:"Digital India 3.0",c:"Governance",imp:"High"},{t:"Carbon Credits Market",c:"Environment",imp:"Medium"},{t:"Semiconductor Mission",c:"S&T",imp:"High"},{t:"NEP 2020 Impact",c:"Social",imp:"Medium"},{t:"PM Kisan Updates",c:"Agriculture",imp:"Medium"}].map(a=>(
            <div key={a.t} style={{padding:"10px 12px",background:"#f8f9fa",borderRadius:8,border:"1px solid #eee"}}>
              <div style={{fontWeight:600,fontSize:13,marginBottom:4}}>{a.t}</div>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <span style={C.tag()}>{a.c}</span>
                <span style={{fontSize:11,color:a.imp==="High"?"#cc3300":"#888",fontWeight:700}}>{a.imp}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const SubjectView = () => {
    const sub = SUBJECTS.find(s=>s.id===activeSub);
    if (!sub) return null;
    return (
      <div>
        <button style={{...C.btn(false),marginBottom:14}} onClick={()=>setView("dashboard")}>← Back</button>
        <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:18}}>
          <span style={{fontSize:36}}>{sub.icon}</span>
          <div>
            <h1 style={{...C.h1,marginBottom:6}}>{sub.name}</h1>
            <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
              <button style={C.btn(true)} onClick={()=>startTest("prelims",activeSub)}>🎯 Prelims PYQ</button>
              <button style={C.btn(false)} onClick={()=>startTest("mains",activeSub)}>📝 Mains PYQ</button>
            </div>
          </div>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(260px,1fr))",gap:12}}>
          {Object.entries(SYLLABUS[activeSub]).map(([topic,subs])=>(
            <div key={topic} style={C.card}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",cursor:"pointer"}}
                onClick={()=>setSyllEx(e=>({...e,[`${activeSub}-${topic}`]:!e[`${activeSub}-${topic}`]}))}>
                <h3 style={{fontSize:15,fontWeight:700,color:sub.color,margin:0}}>{topic}</h3>
                <span style={{color:"#999"}}>{syllEx[`${activeSub}-${topic}`]?"▲":"▼"}</span>
              </div>
              {syllEx[`${activeSub}-${topic}`]&&(
                <div style={{marginTop:10}}>
                  {subs.map(st=>(
                    <div key={st} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"6px 0",borderBottom:"1px solid #f5f5f5"}}>
                      <span style={{fontSize:13}}>{st}</span>
                      <button style={{background:sub.bg,color:sub.color,border:"none",padding:"3px 10px",borderRadius:6,fontSize:12,cursor:"pointer",fontWeight:600}}
                        onClick={()=>{setActiveTopic({sub:sub.name,topic:st,color:sub.color,bg:sub.bg});setAiContent("");setView("topic");}}>
                        Study →
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    );
  };

  const TopicView = () => {
    if (!activeTopic) return null;
    const key = `${activeTopic.sub}-${activeTopic.topic}`;
    return (
      <div>
        <button style={{...C.btn(false),marginBottom:14}} onClick={()=>setView("subject")}>← Back</button>
        <h1 style={{...C.h1,marginBottom:2}}>{activeTopic.topic}</h1>
        <p style={{...C.muted,marginBottom:16}}>{activeTopic.sub}</p>
        <div style={{...C.card,marginBottom:14}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
            <h2 style={{...C.h2,margin:0}}>🤖 AI Study Notes</h2>
            <button style={C.btn(true)} onClick={()=>loadAI(activeTopic.sub,activeTopic.topic)} disabled={aiLoading}>
              {aiLoading?"⏳ Loading...":"Generate Notes"}
            </button>
          </div>
          {aiLoading&&<div style={{textAlign:"center",padding:24,color:"#888"}}>Generating AI study material...</div>}
          {aiContent&&<div style={{background:"#f0f4ff",border:"1px solid #c5d5f5",borderRadius:8,padding:"14px 16px",fontSize:13,lineHeight:1.8,whiteSpace:"pre-wrap",maxHeight:380,overflowY:"auto"}}>{aiContent}</div>}
          {!aiContent&&!aiLoading&&<div style={{color:"#bbb",textAlign:"center",padding:18,fontSize:13}}>Click "Generate Notes" to get AI-powered study material</div>}
        </div>
        <div style={C.card}>
          <h2 style={{...C.h2,marginBottom:10}}>📓 My Notes</h2>
          {(notes[key]||[]).map((n,i)=>(
            <div key={i} style={{padding:"8px 12px",background:"#fffde7",borderRadius:7,marginBottom:6,fontSize:13,border:"1px solid #ffe082"}}>{n}</div>
          ))}
          <div style={{display:"flex",gap:8,marginTop:8}}>
            <input style={C.input} placeholder="Add a note..." value={noteInput} onChange={e=>setNoteInput(e.target.value)}
              onKeyDown={e=>{if(e.key==="Enter"&&noteInput.trim()){setNotes(n=>({...n,[key]:[...(n[key]||[]),noteInput.trim()]}));setNoteInput("");}}}/>
            <button style={C.btn(true)} onClick={()=>{if(noteInput.trim()){setNotes(n=>({...n,[key]:[...(n[key]||[]),noteInput.trim()]}));setNoteInput("");}}}>Add</button>
          </div>
        </div>
      </div>
    );
  };

  const TestView = () => {
    if (testDone) {
      const pct = Math.round((score.correct/score.total)*100);
      return (
        <div style={{maxWidth:580,margin:"0 auto"}}>
          <div style={{...C.card,textAlign:"center",padding:"2rem"}}>
            <div style={{fontSize:56}}>{pct>=70?"🎉":pct>=40?"👍":"📚"}</div>
            <h1 style={{...C.h1,margin:"12px 0 4px"}}>Test Complete!</h1>
            <div style={{fontSize:44,fontWeight:800,color:pct>=70?"#1a6b4a":pct>=40?"#854f0b":"#993c1d",margin:"10px 0"}}>{pct}%</div>
            <div style={{display:"flex",gap:20,justifyContent:"center",marginBottom:22}}>
              {[{v:score.correct,l:"Correct",c:"#1a6b4a"},{v:score.wrong,l:"Wrong",c:"#993c1d"},{v:score.total,l:"Total",c:"#333"}].map(s=>(
                <div key={s.l} style={{textAlign:"center"}}>
                  <div style={{fontSize:22,fontWeight:800,color:s.c}}>{s.v}</div>
                  <div style={C.muted}>{s.l}</div>
                </div>
              ))}
            </div>
            <div style={{display:"flex",gap:8,justifyContent:"center",flexWrap:"wrap"}}>
              <button style={C.btn(true)} onClick={()=>startTest(testMode,null)}>Retake Test</button>
              <button style={C.btn(false)} onClick={()=>setView("dashboard")}>Dashboard</button>
              <button style={C.btn(false)} onClick={()=>setView("pyq")}>View All PYQs</button>
            </div>
          </div>
        </div>
      );
    }
    const q=testQs[testIdx];
    if(!q) return null;
    const isPrelims=q.type==="prelims";
    return (
      <div style={{maxWidth:680,margin:"0 auto"}}>
        <div style={{display:"flex",justifyContent:"space-between",marginBottom:12,alignItems:"center"}}>
          <span style={C.muted}>Q {testIdx+1} / {testQs.length}</span>
          <div style={{display:"flex",gap:6}}>
            <span style={C.tag("#185fa5","#e6f1fb")}>{q.paper}</span>
            <span style={C.tag("#854f0b","#faeeda")}>{q.year}</span>
          </div>
        </div>
        <div style={{height:6,borderRadius:3,background:"#eee",overflow:"hidden",marginBottom:16}}>
          <div style={{height:"100%",width:`${(testIdx/testQs.length)*100}%`,background:"#1a1a2e",borderRadius:3,transition:"width 0.4s"}}/>
        </div>
        <div style={C.card}>
          <p style={{fontSize:15,lineHeight:1.75,fontWeight:500,marginBottom:18,whiteSpace:"pre-line"}}>{q.q}</p>
          {isPrelims&&(
            <div style={{display:"flex",flexDirection:"column",gap:8}}>
              {q.options.map((opt,i)=>{
                let bg="#f8f9fa",border="#e0e0e0",col="#333";
                if(answered){
                  if(i===q.answer){bg="#e1f5ee";border="#1a6b4a";col="#1a6b4a";}
                  else if(i===selected&&i!==q.answer){bg="#faece7";border="#993c1d";col="#993c1d";}
                }
                return(
                  <button key={i} disabled={answered} onClick={()=>handleAnswer(i)}
                    style={{background:bg,border:`2px solid ${border}`,borderRadius:8,padding:"9px 14px",textAlign:"left",cursor:answered?"default":"pointer",color:col,fontSize:13,fontWeight:answered&&i===q.answer?700:400,fontFamily:"inherit"}}>
                    <strong>{String.fromCharCode(65+i)}.</strong> {opt}
                  </button>
                );
              })}
              {answered&&(
                <div style={{background:"#e8f4fd",border:"1px solid #90caf9",borderRadius:8,padding:"10px 14px",marginTop:6,fontSize:13,lineHeight:1.6}}>
                  <strong>📖 Explanation:</strong> {q.explanation}
                </div>
              )}
            </div>
          )}
          {!isPrelims&&(
            <div>
              <div style={{background:"#f5f5f5",borderRadius:8,padding:"10px 14px",marginBottom:10,fontSize:13}}>
                <strong>Marks:</strong> {q.marks} &nbsp;|&nbsp; <strong>Type:</strong> Descriptive Answer
              </div>
              <div style={{fontSize:13,color:"#555",lineHeight:1.7,background:"#fffde7",borderRadius:8,padding:"10px 14px",border:"1px solid #ffe082"}}>
                💡 <strong>Tip:</strong> Introduction → Body (economic, social, political dimensions) → Way Forward
              </div>
            </div>
          )}
        </div>
        <div style={{marginTop:12,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <button style={C.btn(false)} onClick={()=>setView("dashboard")}>← Exit</button>
          {(!isPrelims||answered)&&(
            <button style={C.btn(true)} onClick={nextQ}>
              {testIdx+1>=testQs.length?"See Results 🏁":"Next →"}
            </button>
          )}
        </div>
      </div>
    );
  };

  const PYQView = () => {
    const years=["All",...new Set(PYQ_BANK.map(q=>q.year.toString()))].sort((a,b)=>b-a);
    const filtered=PYQ_BANK.filter(q=>(filterYear==="All"||q.year.toString()===filterYear)&&(filterType==="All"||q.type===filterType));
    return (
      <div>
        <h1 style={{...C.h1,marginBottom:4}}>Previous Year Questions</h1>
        <p style={{...C.muted,marginBottom:14}}>UPSC Prelims & Mains PYQs</p>
        <div style={{display:"flex",gap:8,flexWrap:"wrap",marginBottom:18,alignItems:"center"}}>
          <select style={{...C.input,width:"auto"}} value={filterYear} onChange={e=>setFilterYear(e.target.value)}>
            {years.map(y=><option key={y}>{y}</option>)}
          </select>
          <select style={{...C.input,width:"auto"}} value={filterType} onChange={e=>setFilterType(e.target.value)}>
            {["All","prelims","mains"].map(t=><option key={t}>{t}</option>)}
          </select>
          <button style={C.btn(true)} onClick={()=>startTest(filterType==="mains"?"mains":"prelims",null)}>🎯 Test with Filter</button>
          <span style={C.muted}>{filtered.length} questions</span>
        </div>
        <div style={{display:"flex",flexDirection:"column",gap:10}}>
          {filtered.map((q,i)=>{
            const sub=SUBJECTS.find(s=>s.id===q.subject);
            return(
              <div key={i} style={C.card}>
                <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:8}}>
                  <span style={C.tag("#333","#e8eaf0")}>{q.year}</span>
                  <span style={C.tag(sub?.color,"#fff")}>{q.paper}</span>
                  <span style={C.tag(q.type==="prelims"?"#185fa5":"#854f0b",q.type==="prelims"?"#e6f1fb":"#faeeda")}>{q.type}</span>
                  <span style={C.tag()}>{q.topic}</span>
                  {q.marks&&<span style={C.tag("#1a6b4a","#e1f5ee")}>{q.marks} marks</span>}
                </div>
                <p style={{fontSize:13,lineHeight:1.7,margin:0,whiteSpace:"pre-line"}}>{q.q}</p>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  const SyllabusView = () => (
    <div>
      <h1 style={{...C.h1,marginBottom:4}}>UPSC Complete Syllabus</h1>
      <p style={{...C.muted,marginBottom:18}}>Prelims & Mains — all papers</p>
      {SUBJECTS.map(sub=>(
        <div key={sub.id} style={{...C.card,marginBottom:12,borderLeft:`4px solid ${sub.color}`}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",cursor:"pointer"}}
            onClick={()=>setSyllEx(e=>({...e,[sub.id]:!e[sub.id]}))}>
            <div style={{display:"flex",alignItems:"center",gap:10}}>
              <span style={{fontSize:26}}>{sub.icon}</span>
              <h2 style={{margin:0,fontSize:17,fontWeight:700,color:sub.color}}>{sub.name}</h2>
            </div>
            <span style={{color:"#999",fontSize:18}}>{syllEx[sub.id]?"▲":"▼"}</span>
          </div>
          {syllEx[sub.id]&&(
            <div style={{marginTop:14,display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(200px,1fr))",gap:10}}>
              {Object.entries(SYLLABUS[sub.id]).map(([topic,subs])=>(
                <div key={topic} style={{background:sub.bg,borderRadius:8,padding:"10px 12px"}}>
                  <div style={{fontWeight:700,fontSize:13,color:sub.color,marginBottom:6}}>{topic}</div>
                  {subs.map(s=><div key={s} style={{fontSize:12,color:"#444",padding:"2px 0"}}>• {s}</div>)}
                </div>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  );

  const ChatView = () => (
    <div style={{maxWidth:680,margin:"0 auto"}}>
      <h1 style={{...C.h1,marginBottom:4}}>🤖 AI UPSC Mentor</h1>
      <p style={{...C.muted,marginBottom:14}}>Powered by Claude — ask anything about IAS preparation</p>
      <div style={{...C.card,height:420,overflowY:"auto",display:"flex",flexDirection:"column",gap:10,marginBottom:10,padding:"14px 16px"}}>
        {chatMsgs.map((m,i)=>(
          <div key={i} style={{display:"flex",justifyContent:m.role==="user"?"flex-end":"flex-start"}}>
            <div style={{maxWidth:"80%",padding:"9px 13px",borderRadius:m.role==="user"?"12px 12px 4px 12px":"12px 12px 12px 4px",background:m.role==="user"?"#1a1a2e":"#f0f4ff",color:m.role==="user"?"#ffd700":"#222",fontSize:13,lineHeight:1.7,whiteSpace:"pre-wrap"}}>
              {m.text}
            </div>
          </div>
        ))}
        {chatLoading&&<div style={{color:"#aaa",fontSize:13}}>🤔 Mentor is thinking...</div>}
        <div ref={chatEnd}/>
      </div>
      <div style={{display:"flex",gap:8}}>
        <input style={C.input} placeholder="Ask about topics, strategy, current affairs..." value={chatInput}
          onChange={e=>setChatInput(e.target.value)} onKeyDown={e=>e.key==="Enter"&&sendChat()}/>
        <button style={C.btn(true)} onClick={sendChat} disabled={chatLoading}>Send</button>
      </div>
      <div style={{display:"flex",gap:6,flexWrap:"wrap",marginTop:10}}>
        {["Explain Article 356","UPSC answer writing tips","Difference: prelims vs mains","Important schemes for GS2"].map(s=>(
          <button key={s} style={{background:"#eeedfe",color:"#533489",border:"none",borderRadius:20,padding:"4px 12px",fontSize:11,cursor:"pointer",fontWeight:600,fontFamily:"inherit"}} onClick={()=>setChatInput(s)}>{s}</button>
        ))}
      </div>
    </div>
  );

  const NAV=[{id:"dashboard",l:"🏠 Home"},{id:"syllabus",l:"📚 Syllabus"},{id:"pyq",l:"📋 PYQs"},{id:"chat",l:"🤖 AI Mentor"}];

  return (
    <div style={{fontFamily:"'Segoe UI',system-ui,sans-serif",minHeight:"100vh",background:"#f4f6fa"}}>
      <nav style={C.nav}>
        <div style={C.brand}>UPSC Prep</div>
        <div style={{display:"flex",gap:4,flexWrap:"wrap"}}>
          {NAV.map(n=><button key={n.id} style={C.nb(view===n.id)} onClick={()=>setView(n.id)}>{n.l}</button>)}
        </div>
      </nav>
      <main style={C.main}>
        {view==="dashboard"&&<Dashboard/>}
        {view==="subject"&&<SubjectView/>}
        {view==="topic"&&<TopicView/>}
        {view==="test"&&<TestView/>}
        {view==="pyq"&&<PYQView/>}
        {view==="syllabus"&&<SyllabusView/>}
        {view==="chat"&&<ChatView/>}
      </main>
    </div>
  );
}
