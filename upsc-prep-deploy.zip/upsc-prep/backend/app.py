from flask import Flask, request, jsonify
from flask_cors import CORS
import anthropic
import os

app = Flask(__name__)

# In production, restrict this to your GitHub Pages domain
# e.g. CORS(app, origins=["https://yourusername.github.io"])
CORS(app)

client = anthropic.Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY"))

@app.route("/api/chat", methods=["POST"])
def chat():
    data = request.json
    messages = data.get("messages", [])
    system = data.get("system", "")
    max_tokens = data.get("max_tokens", 800)

    if not messages:
        return jsonify({"error": "No messages provided"}), 400

    try:
        kwargs = {
            "model": "claude-sonnet-4-20250514",
            "max_tokens": max_tokens,
            "messages": messages,
        }
        if system:
            kwargs["system"] = system

        response = client.messages.create(**kwargs)
        return jsonify({"content": response.content[0].text})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/notes", methods=["POST"])
def notes():
    data = request.json
    subject = data.get("subject", "")
    topic = data.get("topic", "")

    if not topic:
        return jsonify({"error": "Topic required"}), 400

    try:
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1000,
            messages=[{
                "role": "user",
                "content": f'Create a concise UPSC study note for "{topic}" under {subject}. Include: 1) Key concepts (3-5 bullets), 2) Important facts/data for exam, 3) One practice question with answer. Format with clear headings. Max 350 words.'
            }]
        )
        return jsonify({"content": response.content[0].text})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/health")
def health():
    return jsonify({"status": "ok"})

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
