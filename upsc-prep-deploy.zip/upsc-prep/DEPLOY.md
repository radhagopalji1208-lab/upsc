# UPSC Prep — Deployment Guide

## Project Structure

```
upsc-prep/
├── backend/          ← Python Flask API (deployed on Railway)
│   ├── app.py
│   ├── requirements.txt
│   ├── Procfile
│   └── .env.example
└── frontend/         ← React app (deployed on GitHub Pages)
    ├── package.json
    ├── public/
    └── src/
        ├── App.js
        ├── index.js
        └── api.js
```

---

## Step 1 — Deploy the Backend (Railway — free tier)

The backend keeps your Anthropic API key secret on the server.

1. Go to https://railway.app and sign up (free)
2. Create a new project → "Deploy from GitHub repo"
3. Push the `backend/` folder to a GitHub repo (or use the Railway CLI)
4. In Railway dashboard → Variables tab, add:
   ```
   ANTHROPIC_API_KEY = sk-ant-your-key-here
   ```
5. Railway auto-detects the Procfile and deploys
6. Copy your Railway URL (e.g. `https://upsc-backend.railway.app`)

> **Alternative**: Render.com also works. Use the same steps — it's also free.

---

## Step 2 — Configure the Frontend

Open `frontend/src/api.js` and set your backend URL:

```js
const BACKEND_URL = "https://upsc-backend.railway.app";  // ← your Railway URL
```

Or create `frontend/.env.local`:
```
REACT_APP_BACKEND_URL=https://upsc-backend.railway.app
```

---

## Step 3 — Configure GitHub Pages

Open `frontend/package.json` and update the homepage field:
```json
"homepage": "https://YOUR_GITHUB_USERNAME.github.io/upsc-prep"
```
Replace `YOUR_GITHUB_USERNAME` with your actual GitHub username.

---

## Step 4 — Deploy Frontend to GitHub Pages

```bash
cd frontend

# Install dependencies
npm install

# Deploy to GitHub Pages (builds + pushes to gh-pages branch)
npm run deploy
```

Your site will be live at:
`https://YOUR_GITHUB_USERNAME.github.io/upsc-prep`

---

## Step 5 — Restrict Backend CORS (important for security)

Once deployed, edit `backend/app.py` line 8 to only allow your GitHub Pages domain:

```python
CORS(app, origins=["https://YOUR_GITHUB_USERNAME.github.io"])
```

Re-deploy the backend after this change.

---

## Local Development

**Backend:**
```bash
cd backend
pip install -r requirements.txt
cp .env.example .env
# Edit .env and add your ANTHROPIC_API_KEY
python app.py
```

**Frontend:**
```bash
cd frontend
npm install
npm start
# Opens at http://localhost:3000
```

---

## Summary

| Component | Platform | Cost | URL |
|-----------|----------|------|-----|
| Backend (Flask) | Railway / Render | Free | yourapp.railway.app |
| Frontend (React) | GitHub Pages | Free | username.github.io/upsc-prep |

Total cost: **₹0** 🎉
